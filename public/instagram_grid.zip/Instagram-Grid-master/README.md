# Instagram-Grid
An Instagram layout made with css grids module

![Screenshot](docs/screenshot.png)